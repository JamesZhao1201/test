import itertools
from collections import defaultdict

def load_data(filepath):
    with open(filepath, 'r') as file:
        for line in file:
            yield set(line.strip().split())  


def find_frequent_singletons(baskets, support_threshold, total_baskets):
    item_counts = defaultdict(int)
    for basket in baskets:
        for item in basket:
            item_counts[item] += 1

    threshold_count = support_threshold * total_baskets

    frequent_items = {item for item, count in item_counts.items() if count >= threshold_count}
    return frequent_items


def find_frequent_pairs(baskets, frequent_items, support_threshold, total_baskets):
    pair_counts = defaultdict(int)
    for basket in baskets:
        frequent_in_basket = [item for item in basket if item in frequent_items]
        for pair in itertools.combinations(frequent_in_basket, 2):
            pair_counts[pair] += 1
    threshold_count = support_threshold * total_baskets
    frequent_pairs = {pair: count for pair, count in pair_counts.items() if count >= threshold_count}
    return frequent_pairs


def get_top_frequent_pairs(frequent_pairs, top_n=30):
    sorted_pairs = sorted(frequent_pairs.items(), key=lambda x: x[1], reverse=True)
    return sorted_pairs[:top_n]


support_threshold = 0.01  
file_path = 'test_input.txt' 


total_baskets = sum(1 for _ in open(file_path))


baskets_gen = load_data(file_path)
frequent_items = find_frequent_singletons(baskets_gen, support_threshold, total_baskets)


baskets_gen = load_data(file_path)  
frequent_pairs = find_frequent_pairs(baskets_gen, frequent_items, support_threshold, total_baskets)


top_pairs = get_top_frequent_pairs(frequent_pairs)



for pair, count in top_pairs:
    print(f"{pair}: {count}")
