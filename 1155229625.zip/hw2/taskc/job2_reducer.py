#!/usr/bin/env python3
import sys
from heapq import nlargest

def reduce_phase():
    triplet_counts = {}

    for line in sys.stdin:
        triplet, count = line.strip().split('\t')
        count = int(count)

        if triplet in triplet_counts:
            triplet_counts[triplet] += count
        else:
            triplet_counts[triplet] = count

    # Get top 50 frequent triplets
    top_50_triplets = nlargest(50, triplet_counts.items(), key=lambda x: x[1])

    # Print triplets matching the SID requirement
    for rank, (triplet, count) in enumerate(top_50_triplets, start=1):
       if rank % 10 == 5:  # SID 尾数是 5，显示 5th, 15th, 25th 等排名的项
            print(f"{triplet}\t{count}")
if __name__ == "__main__":
    reduce_phase()
