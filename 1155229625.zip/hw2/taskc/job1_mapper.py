#!/usr/bin/env python3
import sys
import itertools
from collections import defaultdict

def map_phase():
    item_counts = defaultdict(int)
    baskets = []

    for line in sys.stdin:
        basket = set(line.strip().split())
        if not basket:
            continue
        baskets.append(basket)
        for item in basket:
            item_counts[item] += 1

    # Set threshold for frequent items
    threshold = 0.005 * len(baskets)
    frequent_items = {item for item, count in item_counts.items() if count >= threshold}

    # Find candidate triplets
    triplet_counts = defaultdict(int)
    for basket in baskets:
        frequent_items_in_basket = [item for item in basket if item in frequent_items]
        for triplet in itertools.combinations(sorted(frequent_items_in_basket), 3):
            triplet_counts[triplet] += 1

    # Output candidate triplets
    for triplet, count in triplet_counts.items():
        if count >= threshold:
            print(f"{triplet[0]},{triplet[1]},{triplet[2]}\t{count}")

if __name__ == "__main__":
    map_phase()
