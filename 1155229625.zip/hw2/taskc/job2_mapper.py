#!/usr/bin/env python3
import sys
import itertools  # 添加导入

# Load candidate triplets from the file
candidate_triplets = set()
with open('candidates.txt', 'r') as file:
    for line in file:
        triplet = tuple(line.strip().split(','))
        candidate_triplets.add(triplet)

def map_phase():
    for line in sys.stdin:
        basket = set(line.strip().split())
        for triplet in itertools.combinations(sorted(basket), 3):
            if triplet in candidate_triplets:
                print(f"{triplet[0]},{triplet[1]},{triplet[2]}\t1")

if __name__ == "__main__":
    map_phase()
