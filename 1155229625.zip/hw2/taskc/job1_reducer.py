#!/usr/bin/env python3
import sys

def reduce_phase():
    current_triplet = None
    current_count = 0

    for line in sys.stdin:
        triplet, count = line.strip().split('\t')
        count = int(count)

        if current_triplet == triplet:
            current_count += count
        else:
            if current_triplet is not None:
                print(f"{current_triplet}\t{current_count}")
            current_triplet = triplet
            current_count = count

    if current_triplet is not None:
        print(f"{current_triplet}\t{current_count}")

if __name__ == "__main__":
    reduce_phase()
