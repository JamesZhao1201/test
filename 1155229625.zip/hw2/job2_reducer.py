#!/usr/bin/env python3
import sys
from heapq import nlargest

def reduce_phase():
    pair_counts = {}

    for line in sys.stdin:
        pair, count = line.strip().split('\t')
        count = int(count)

        if pair in pair_counts:
            pair_counts[pair] += count
        else:
            pair_counts[pair] = count

    # 获取出现次数最多的前 30 个项对
    top_30_pairs = nlargest(30, pair_counts.items(), key=lambda x: x[1])

    # 输出前 30 个项对及其计数
    for pair, count in top_30_pairs:
        print(f"{pair}\t{count}")

if __name__ == "__main__":
    reduce_phase()
