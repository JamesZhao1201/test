#!/usr/bin/env python3
import sys
import itertools
from collections import defaultdict

def map_phase():
    item_counts = defaultdict(int)
    baskets = []

    # Read input once and store in baskets
    for line in sys.stdin:
        basket = set(line.strip().split())
        if not basket:
            continue
        baskets.append(basket)
        for item in basket:
            item_counts[item] += 1

    # Set threshold for frequent items
    threshold = 0.01 * len(baskets)
    frequent_items = {item for item, count in item_counts.items() if count >= threshold}

    # Find candidate pairs
    pair_counts = defaultdict(int)
    for basket in baskets:
        frequent_items_in_basket = [item for item in basket if item in frequent_items]
        for pair in itertools.combinations(sorted(frequent_items_in_basket), 2):
            pair_counts[pair] += 1

    # Output candidate pairs
    for pair, count in pair_counts.items():
        if count >= threshold:
            print(f"{pair[0]},{pair[1]}\t{count}")

if __name__ == "__main__":
    map_phase()
