#!/usr/bin/env python3
import sys
import itertools  # 添加这一行以导入 itertools

# 加载候选频繁项对
candidate_pairs = set()
with open('candidates.txt', 'r') as file:
    for line in file:
        pair = tuple(line.strip().split(','))
        candidate_pairs.add(pair)

def map_phase():
    for line in sys.stdin:
        basket = set(line.strip().split())
        for pair in itertools.combinations(sorted(basket), 2):
            if pair in candidate_pairs:
                print(f"{pair[0]},{pair[1]}\t1")

if __name__ == "__main__":
    map_phase()
